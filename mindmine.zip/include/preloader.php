<div class="preloader_wrap">
    <img src="assets/img/logo.png" style="height: 70px;" class="pre_logo" alt="">
    <span class="preloader"></span>
</div>