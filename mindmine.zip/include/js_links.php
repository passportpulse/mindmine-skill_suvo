
	<!-- Latest jQuery -->
	<script src="assets/js/jquery.min.js"></script>
	<!-- bootstrap.bundle js -->
	<script src="assets/bootstrap/js/bootstrap.bundle.js"></script>
	<!-- jquery-simple-mobilemenu.min -->
	<script src="assets/js/jquery.meanmenu.min.js"></script>
	<!-- modernizer JS -->
	<script src="assets/js/modernizr-2.8.3.min.js"></script>
	<!-- owl-carousel min js  -->
	<script src="assets/owlcarousel/js/owl.carousel.min.js"></script>
	<!-- phosphor-icons js  -->
	<script src="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1"></script>
	<!-- waypoints -->
	<script src="assets/js/jquery.inview.min.js"></script>
	<!-- magnific-popup js -->
	<script src="assets/js/jquery.magnific-popup.js"></script>
	<!-- swiper-bundle.min js -->
	<script src="assets/js/swiper-bundle.min.js"></script>
	<!-- YouTubePopUp js -->
	<script src="assets/js/YouTubePopUp.jquery.js"></script>
	<!-- yvpopup-active js -->
	<script src="assets/js/yvpopup-active.js"></script>
	<!-- Mixitup js -->
	<script src="assets/js/mixitup.min.js"></script>
	<!-- Wow js -->
	<script src="assets/js/wow.js"></script>
	<!-- slick js -->
	<script src="assets/js/slick.js"></script>
	<!-- scroll-top js -->
	<script src="assets/js/scroll-top.js"></script>
	<!-- scripts js -->
	<script src="assets/js/scripts.js"></script>
	<script>
		// START Recomanded
		var mixproduct = mixitup('.program_items');
		// END Recomanded
	</script>