/*Video Popup*/

jQuery(".vplay_btn").YouTubePopUp();
jQuery(".cvbtn").YouTubePopUp();